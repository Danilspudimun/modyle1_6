# Работа со словарями
my_dict = {'Danila': 1999, 'Yana': 1994, 'Oleg': 1969}
print(my_dict)
print(my_dict['Danila'])
print(my_dict.get('Irina'))
number = my_dict.pop('Yana')
print(number)
my_dict.update({'Sergey': 1977, ' Dima': 2013})
del my_dict['Sergey']
print(my_dict)

# Работа со множествами
my_set = { 1,2,3, 'Star', 3.14, 5,6,7,8,1,2,3}
print(my_set)
my_set.add('Luna')
my_set.add(25)
my_set.discard(3)
print(my_set)
